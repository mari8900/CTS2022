package ro.ase.cts.g1099.assignment2.interfaces;

public interface MonthlyRate {
	double getMonthlyRate();
}
